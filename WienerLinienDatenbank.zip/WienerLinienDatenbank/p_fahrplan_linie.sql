-- PROCEDURE

-- Einer Procedure soll die Bezeichnung einer Linie übergeben werden
-- und alle Haltestellen dieser Linie der Reihenfolge nach anzeigen.

set serveroutput on;

CREATE OR REPLACE PROCEDURE fahrplan_linie (c_liniename varChar) AS
  cursor c_linie is
  SELECT reihenfolgenID, haltestelle.bezeichnung FROM linie_haltestelle
    JOIN linie USING (linienID)
    JOIN haltestelle USING (haltestellenID)
    WHERE linie.bezeichnung = c_liniename
    ORDER BY reihenfolgenid;
  v_result c_linie%rowtype;
  errno integer;
  errmsg varchar2(200);
  EX1 EXCEPTION;
  counter number;
BEGIN
	counter := 0;
  SELECT COUNT(linienID) INTO counter FROM linie WHERE linie.bezeichnung = c_liniename;
  IF (counter = 0) THEN
    errno := -20105; errmsg := 'Keine Linie mit Namen: ' || c_liniename ;raise EX1;
  ELSE
    DBMS_OUTPUT.PUT_LINE( 'Linie ' || c_liniename || ':');
    OPEN c_linie;
    LOOP
    	fetch c_linie INTO v_result;
    	EXIT WHEN c_linie%notfound;
      DBMS_OUTPUT.PUT_LINE(v_result.reihenfolgenID || '. ' || v_result.bezeichnung);
    END loop;
    close c_linie;
  END IF;
  exception
  WHEN EX1 THEN
    raise_application_error(errno, errmsg);
END;
/

-- Drop
DROP VIEW fahrplan_linie;
-- Execute
exec fahrplan_linie('13A'); -- erfolgreich
exec fahrplan_linie('U4'); -- erfolgreich
exec fahrplan_linie('1'); -- erfolgreich
exec fahrplan_linie('xyz'); -- Error: Keine Linie vorhanden
