-- VIEW

-- Eine View zum Anzeigen aller Stationen, welche Lifte besitzen
-- Es soll weiteres die Anzahl der Aktiven/Defekten Lifte sowie deren in Bearbeitung angezeigt werden.

CREATE OR REPLACE VIEW v_lift_haltestelle_status
AS
SELECT * FROM (
SELECT haltestelle.bezeichnung, COUNT(status.bezeichnung) as aktiv FROM haltestelle
  JOIN lift ON lift.haltestellenID = haltestelle.haltestellenID
  JOIN status ON status.statusID = lift.statusID
  WHERE status.bezeichnung = 'Aktiv'
  GROUP BY haltestelle.bezeichnung)
FULL JOIN
(SELECT haltestelle.bezeichnung, COUNT(status.bezeichnung) as defekt FROM haltestelle
  JOIN lift ON lift.haltestellenID = haltestelle.haltestellenID
  JOIN status ON status.statusID = lift.statusID
  WHERE status.bezeichnung = 'Defekt'
  GROUP BY haltestelle.bezeichnung) USING (bezeichnung)
FULL JOIN
(SELECT haltestelle.bezeichnung, COUNT(status.bezeichnung) as inbearbeitung FROM haltestelle
  JOIN lift ON lift.haltestellenID = haltestelle.haltestellenID
  JOIN status ON status.statusID = lift.statusID
  WHERE status.bezeichnung = 'in Bearbeitung'
  GROUP BY haltestelle.bezeichnung) USING (bezeichnung);


-- Drop
DROP VIEW v_lift_haltestelle_status;
-- Execute
SELECT * FROM v_lift_haltestelle_status;
