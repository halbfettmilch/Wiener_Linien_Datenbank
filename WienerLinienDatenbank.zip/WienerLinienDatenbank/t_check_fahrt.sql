-- TRIGGER

-- Beim Einfügen einer Fahrt muss drauf geachtet werden,
-- dass die/das übergebene Linie/Personal/Fahrzeug existieren
-- und auf einer Buslinie nur Busse, einer Straßenbahnlinie nur Straßenbahnen, einer UBahnlinie nur Ubahnen fahren,
-- sowie eine entsprechende aussagestarke Fehlermeldung werfen.

CREATE OR REPLACE TRIGGER check_fahrt
BEFORE INSERT ON fahrt
FOR EACH ROW
DECLARE
  i_linienCount number;
  i_fahrzeugCount number;
  i_personalCount number;
  v_linienArt varchar2(200);
  v_modellArt varchar2(200);
  errno integer;
  errmsg varchar2(200);
  EX1 EXCEPTION;
BEGIN
  SELECT COUNT(linienID) INTO i_linienCount FROM linie WHERE linie.linienID = :new.linienID;
  SELECT COUNT(fahrzeugID) INTO i_fahrzeugCount FROM fahrzeug WHERE fahrzeug.fahrzeugID = :new.fahrzeugID;
  SELECT COUNT(personID) INTO i_personalCount FROM personal WHERE personal.personID = :new.personID;
  IF (i_linienCount != 1) THEN
    errno := -20101; errmsg := 'Keine Linie mit ID: ' || :new.linienID ;raise EX1;
  ELSIF (i_fahrzeugCount != 1) THEN
    errno := -20102; errmsg := 'Kein Fahrzeug mit ID: ' || :new.fahrzeugID ;raise EX1;
  ELSIF (i_personalCount != 1) THEN
    errno := -20103; errmsg := 'Kein Personal mit ID: ' || :new.personID ;raise EX1;
  ELSE
    SELECT linienArt INTO v_linienArt FROM linie WHERE linie.linienID = :new.linienID;
    SELECT modellArt INTO v_modellArt FROM fahrzeug JOIN modelltyp USING (modelltypID) WHERE fahrzeug.fahrzeugID = :new.FAHRZEUGID;
    IF (v_linienArt = v_modellArt) THEN
      errno := -20101; errmsg := v_modellArt || ' kann nicht auf einer ' || v_linienArt || 'linie eingesetzt werden!' ;raise EX1;
    END IF;
  END IF;
exception
WHEN EX1 THEN
  raise_application_error(errno, errmsg);
END;
/

-- INSERT
-- (FAHRTID,FAHRZEUGID,LINIENID,PERSONID,STARTZEIT)
INSERT INTO fahrt VALUES (50,11,101,10,to_timestamp('01.01.2021 12:00:00','DD.MM.YYYY HH24:MI:SS')); -- erlaubt
INSERT INTO fahrt VALUES (51,22,203,11,to_timestamp('01.01.2021 12:00:00','DD.MM.YYYY HH24:MI:SS')); -- erlaubt
INSERT INTO fahrt VALUES (52,35,302,12,to_timestamp('01.01.2021 12:00:00','DD.MM.YYYY HH24:MI:SS')); -- erlaubt
INSERT INTO fahrt VALUES (53,24,101,13,to_timestamp('01.01.2021 12:00:00','DD.MM.YYYY HH24:MI:SS')); -- Error: Straßenbahn/Buslinie
INSERT INTO fahrt VALUES (54,35,202,14,to_timestamp('01.01.2021 12:00:00','DD.MM.YYYY HH24:MI:SS')); -- Error: Ubahn/Straßenbahnlinie
INSERT INTO fahrt VALUES (55,14,303,15,to_timestamp('01.01.2021 12:00:00','DD.MM.YYYY HH24:MI:SS')); -- Error: Bus/UBahnlinie
INSERT INTO fahrt VALUES (56,14,303,9999,to_timestamp('01.01.2021 12:00:00','DD.MM.YYYY HH24:MI:SS')); -- Error: Personal existiert nicht
INSERT INTO fahrt VALUES (57,9999,303,15,to_timestamp('01.01.2021 12:00:00','DD.MM.YYYY HH24:MI:SS')); -- Error: Fahrzeug existiert nicht
INSERT INTO fahrt VALUES (58,14,9999,15,to_timestamp('01.01.2021 12:00:00','DD.MM.YYYY HH24:MI:SS')); -- Error: Linie existiert nicht

-- DELETE
DELETE FROM fahrt WHERE fahrtID = 50;
DELETE FROM fahrt WHERE fahrtID = 51;
DELETE FROM fahrt WHERE fahrtID = 52;
DELETE FROM fahrt WHERE fahrtID = 53;
DELETE FROM fahrt WHERE fahrtID = 54;
DELETE FROM fahrt WHERE fahrtID = 55;
DELETE FROM fahrt WHERE fahrtID = 56;
DELETE FROM fahrt WHERE fahrtID = 57;
DELETE FROM fahrt WHERE fahrtID = 58;

-- DROP
DROP TRIGGER check_fahrt;
