-- VIEW

-- Eine View zum Anzeigen aller Linien, deren Art und der Anzahl an anzufahrenden Haltestellen,
-- sowie dessen Startpunkt.

CREATE OR REPLACE VIEW v_linie_haltestellen_count
AS
SELECT * FROM(
SELECT linie.bezeichnung as id, linienart, COUNT(linie.bezeichnung) AS anzahl_haltestellen FROM linie
  JOIN linie_haltestelle ON linie_haltestelle.linienid = linie.linienid
  JOIN haltestelle ON haltestelle.haltestellenid = linie_haltestelle.haltestellenid
  GROUP BY linie.bezeichnung, linienart)
JOIN
(SELECT linie.bezeichnung as id, haltestelle.bezeichnung as anfang FROM linie
  JOIN linie_haltestelle ON linie_haltestelle.linienid = linie.linienid
  JOIN haltestelle ON haltestelle.haltestellenid = linie_haltestelle.haltestellenid
  WHERE reihenfolgenID = 1)
USING (id);

-- Drop
DROP VIEW v_linie_haltestellen_count;
-- Execute
SELECT * FROM v_linie_haltestellen_count;
