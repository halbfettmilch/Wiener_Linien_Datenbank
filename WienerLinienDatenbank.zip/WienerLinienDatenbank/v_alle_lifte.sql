-- VIEW

-- Eine View zum Anzeigen aller Lifte, dessen Status und deren Haltestelle.
-- In der Ausgabe sollen Daten zur LiftID, der Bezeichnung der zugehörigen Haltestelle,
-- des Liftstatus, sowie des Baujahres und der Kapazität des Liftes angezeigt werden.

CREATE OR REPLACE VIEW v_alle_lifte
AS
SELECT haltestelle.bezeichnung, liftID, personenanzahl, EXTRACT(YEAR FROM baujahr) as baujahr, status.bezeichnung as status FROM lift
JOIN haltestelle USING(haltestellenid)
JOIN status USING (statusID);


-- Drop
DROP VIEW v_alle_lifte;
-- Execute
SELECT * FROM v_alle_lifte;
