-- PROCEDURE

-- Eine Procedure welche die Fahrscheine gesuchter Kunden und deren Gültigkeit ausgibt.
-- Der Procedure wird ein Name übergeben. Dieser besteht aus der Kombination von Vorname und Nachname,
-- welche mit einem ' ' getrennt werden. Es soll auch erlaubt sein Wildcards zu verwenden.
-- Falls es keinen Fahrschein zu der gefunden Person gibt sollen die Felder leer sein und abgelaufen angezeigt werden.

set serveroutput on;

CREATE OR REPLACE PROCEDURE gueltigkeit_fahrschein (i_name varChar)
AS
  CURSOR kunden_info IS
  SELECT * FROM person
    FULL JOIN fahrschein USING (personID)
    FULL JOIN FAHRSCHEINTYP USING (fahrscheintypID)
    WHERE (vorname || ' ' || nachname) LIKE i_name OR (nachname || ' ' || vorname) LIKE i_name;
  v_result kunden_info%rowtype;
  errno integer;
  errmsg varchar2(200);
  EX1 EXCEPTION;
  counter NUMBER;
  maxFahrscheinID NUMBER;
  ablaufdatum DATE;
BEGIN
  SELECT COUNT(personID) INTO counter FROM person WHERE (vorname || ' ' || nachname) LIKE i_name OR (nachname || ' ' || vorname) LIKE i_name;
  IF (counter = 0) THEN
    errno := -20105; errmsg := 'Keine Person mit Namen: ' || i_name ;raise EX1;
  ELSE
    dbms_output.put_line ('Gefundene Personen: ');
    OPEN kunden_info;
    LOOP
      fetch kunden_info INTO v_result;
      EXIT WHEN kunden_info%notfound;
      dbms_output.put_line ( '-------------------');
      dbms_output.put_line ( 'Name: ' || v_result.vorname || ' ' || v_result.nachname);
      dbms_output.put_line ( 'FahrscheinID: ' || v_result.fahrscheinID);
      dbms_output.put_line ( 'FahrscheinTyp: ' || v_result.bezeichnung);
      dbms_output.put_line ( 'Kaufdatum: ' || v_result.ausstellungsdatum);
      IF (v_result.fahrscheintypID = 10 OR v_result.fahrscheintypID = 11) THEN
        SELECT v_result.ausstellungsdatum + INTERVAL '1' HOUR INTO ablaufdatum FROM dual;
      ELSIF (v_result.fahrscheintypID = 12) THEN
        SELECT v_result.ausstellungsdatum + INTERVAL '7' MONTH INTO ablaufdatum FROM dual;
      ELSIF (v_result.fahrscheintypID = 13) THEN
        SELECT v_result.ausstellungsdatum + INTERVAL '6' HOUR INTO ablaufdatum FROM dual;
      ELSIF (v_result.fahrscheintypID = 14) THEN
        SELECT v_result.ausstellungsdatum + INTERVAL '1' HOUR INTO ablaufdatum FROM dual;
      ELSIF (v_result.fahrscheintypID = 15) THEN
        SELECT v_result.ausstellungsdatum + INTERVAL '1' YEAR INTO ablaufdatum FROM dual;
      ELSIF (v_result.fahrscheintypID = 16) THEN
        SELECT v_result.ausstellungsdatum + INTERVAL '72' HOUR INTO ablaufdatum FROM dual;
      END IF;
      IF (ablaufdatum > sysdate) THEN
        dbms_output.put_line ( 'Gültigkeit: gültig');
      ELSE
        dbms_output.put_line ( 'Gültigkeit: abgelaufen');
      END IF;
    END loop;
      close kunden_info;
  END IF;
  exception
  WHEN EX1 THEN
    raise_application_error(errno, errmsg);
END;
/

-- Drop
DROP VIEW gueltigkeit_fahrschein;
-- Execute
exec gueltigkeit_fahrschein('Miau%'); -- 1x (noch) gültig, 1x abgelaufen
exec gueltigkeit_fahrschein('Sebastian Kurz'); -- 1x (noch) gültig, 1x abgelaufen
exec gueltigkeit_fahrschein('Kurz Sebastian'); -- 1x (noch) gültig, 1x abgelaufen
exec gueltigkeit_fahrschein('Tom%'); -- 1x abgelaufen
exec gueltigkeit_fahrschein('Spider%'); -- 1x abgelaufen (kein Fahrschein)
exec gueltigkeit_fahrschein('S%'); -- gültig/abgelaufen/(kein Fahrschein)
exec gueltigkeit_fahrschein('xyz'); -- Error: Keine Person vorhanden
