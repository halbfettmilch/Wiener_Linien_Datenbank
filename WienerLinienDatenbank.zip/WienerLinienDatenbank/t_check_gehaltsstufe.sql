-- TRIGGER

-- Es soll ein Trigger geschrieben werden, welcher beim Updaten eines Personals prüft, ob die neue gehaltsstufe existiert.
-- Falls nicht, soll eine neue Gehaltsstufe mit dem niedrigsten Monatsgehalt erstellt werden.


CREATE OR REPLACE TRIGGER check_monatsgehalt
BEFORE UPDATE ON personal
FOR EACH ROW
DECLARE
  i_gehaltsstufe_count NUMBER;
  i_monatsgehalt_min NUMBER;
BEGIN
  SELECT COUNT(gehaltsstufeID) INTO i_gehaltsstufe_count FROM gehaltsstufe WHERE gehaltsstufe.gehaltsstufeID = :new.gehaltsstufeID;
  IF (i_gehaltsstufe_count = 0) THEN
    SELECT MIN(monatsgehalt) INTO i_monatsgehalt_min FROM gehaltsstufe;
    INSERT INTO gehaltsstufe VALUES (:new.gehaltsstufeID,i_monatsgehalt_min);
  END IF;
END;
/

-- SELECT
SELECT * FROM gehaltsstufe;
SELECT * FROM personal where personID = ;
-- UPDATE
UPDATE personal SET gehaltsstufeID = 99 WHERE personID = 2;

-- DROP
DROP TRIGGER check_monatsgehalt;
